const newelement = document.createElement("h2");
newelement.textContent="siddhi sehgal";
newelement.id="second";


const element = document.getElementById("first");
element.after(newelement);



const newelement2 = document.createElement("h3");
newelement2.textContent="how are you";
newelement2.id="third";


element.before(newelement2);


const arr = ["milk","halwa","daal","chawal","paneer","rice","water"]

const ulelement = document.getElementById("listing");
const fragment = document.createDocumentFragment();

for(let food of arr){
    const list = document.createElement("li");
    list.textContent= food;
    fragment.append(list);
}

ulelement.append(fragment);




